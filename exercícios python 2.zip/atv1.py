numero= int(input('insira um numero: '))

conta= numero **2

print('o resultado é:', conta)