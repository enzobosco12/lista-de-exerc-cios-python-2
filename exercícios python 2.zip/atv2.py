digito1= (input('Insira algo:' ))
digito2= (input('Insira algo:' ))

print('O primeiro dígito foi:', digito1)
print('O segundo dígito foi:', digito2)

