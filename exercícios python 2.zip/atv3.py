digito= int(input('insira um numero inteiro:'))

antecessor= digito-1
sucessor= digito+1

print('o antecessor é:', antecessor)
print('o sucessor é:', sucessor)
