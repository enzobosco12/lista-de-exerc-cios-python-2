altura= float(input('insira a altura:'))
base= float(input('insira o valor da base:'))

perimetro= base+altura
area= base*altura


print('o perímetro é:', perimetro)
print('a área é:', area)
